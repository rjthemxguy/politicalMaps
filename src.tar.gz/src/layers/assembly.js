import { GeoJSON} from "react-leaflet";
import { useRef} from "react";

export const AssemblyLayer = ({data}) => {

    const geoJsonRef = useRef();

    const onEachClick = (feature, layer) => {
        console.log("test");

        const name = feature.properties.name;

        layer.bindPopup(
            "Name: <b>" + name + "</b><br>Density: <b>" + "test" + "</b>"
          );

          layer.on({ click: handleFeatureClick });

    }

    const handleFeatureClick = (e) => {
        if (!geoJsonRef.current) return;
        geoJsonRef.current.resetStyle();
    
        const layer = e.target;
    
        layer.setStyle({ color: "red" });
      };

    return (<GeoJSON  data = {data}
        onEachFeature = {onEachClick}
        ref={geoJsonRef}
        color="blue"
    ></GeoJSON>)
}