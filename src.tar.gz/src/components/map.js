import React from 'react'
import { MapContainer, TileLayer, Marker, Popup} from 'react-leaflet';
import { assembly } from '../data/assembly';
import { AssemblyLayer } from '../layers/assembly';



const Map = () => {

    const position = [34.0483, -117.2612]

  return (
    <div className="App">
    <MapContainer center={[34.0483, -117.2612]} zoom={12}scrollWheelZoom={false}>
     <TileLayer
   url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
   attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
     />
<Marker position={position}>
     <Popup>
       A pretty CSS3 popup. <br /> Easily customizable.
     </Popup>
   </Marker>
    <AssemblyLayer data={assembly}></AssemblyLayer>
   </MapContainer>
   </div>
  )
}

export default Map